import pygame
import random

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 300, 600
BLOCK_SIZE = 30
COLS, ROWS = WIDTH // BLOCK_SIZE, HEIGHT // BLOCK_SIZE

# Colors
BLACK = (0, 0, 0)
GRAY = (128, 128, 128)
COLORS = [
    (0, 255, 255),  # Cyan
    (0, 0, 255),    # Blue
    (255, 165, 0),  # Orange
    (255, 255, 0),  # Yellow
    (0, 255, 0),    # Green
    (128, 0, 128),  # Purple
    (255, 0, 0)     # Red
]

# Tetris shapes (as rotations)
SHAPES = [
    [[1, 1, 1, 1]],                       # I
    [[1, 1, 1], [0, 1, 0]],               # T
    [[1, 1, 1], [1, 0, 0]],               # L
    [[1, 1, 1], [0, 0, 1]],               # J
    [[1, 1], [1, 1]],                     # O
    [[0, 1, 1], [1, 1, 0]],               # S
    [[1, 1, 0], [0, 1, 1]]                # Z
]

# Game grid
grid = [[BLACK for _ in range(COLS)] for _ in range(ROWS)]

def draw_grid(screen):
    for y in range(ROWS):
        for x in range(COLS):
            pygame.draw.rect(screen, grid[y][x], (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)
            pygame.draw.rect(screen, GRAY, (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 1)

class Piece:
    def __init__(self, shape):
        self.shape = shape
        self.color = random.choice(COLORS)
        self.x = COLS // 2 - len(shape[0]) // 2
        self.y = 0

    def rotate(self):
        self.shape = [list(row) for row in zip(*self.shape[::-1])]

def valid_position(piece, dx=0, dy=0):
    for y, row in enumerate(piece.shape):
        for x, cell in enumerate(row):
            if cell:
                new_x, new_y = piece.x + x + dx, piece.y + y + dy
                if new_x < 0 or new_x >= COLS or new_y >= ROWS:
                    return False
                if new_y >= 0 and grid[new_y][new_x] != BLACK:
                    return False
    return True

def place_piece(piece):
    for y, row in enumerate(piece.shape):
        for x, cell in enumerate(row):
            if cell:
                grid[piece.y + y][piece.x + x] = piece.color

def clear_lines():
    global grid
    new_grid = [row for row in grid if any(cell == BLACK for cell in row)]
    lines_cleared = ROWS - len(new_grid)
    for _ in range(lines_cleared):
        new_grid.insert(0, [BLACK for _ in range(COLS)])
    grid = new_grid

def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Mini Tetris")

    clock = pygame.time.Clock()
    piece = Piece(random.choice(SHAPES))
    fall_time = 0

    running = True
    while running:
        screen.fill(BLACK)
        fall_time += clock.get_rawtime()
        clock.tick(30)

        if fall_time > 500:  # Piece falls every 0.5s
            fall_time = 0
            if valid_position(piece, dy=1):
                piece.y += 1
            else:
                place_piece(piece)
                clear_lines()
                piece = Piece(random.choice(SHAPES))
                if not valid_position(piece):
                    running = False  # Game over

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and valid_position(piece, dx=-1):
                    piece.x -= 1
                elif event.key == pygame.K_RIGHT and valid_position(piece, dx=1):
                    piece.x += 1
                elif event.key == pygame.K_DOWN and valid_position(piece, dy=1):
                    piece.y += 1
                elif event.key == pygame.K_UP:
                    old_shape = piece.shape
                    piece.rotate()
                    if not valid_position(piece):
                        piece.shape = old_shape

        # Draw current piece
        for y, row in enumerate(piece.shape):
            for x, cell in enumerate(row):
                if cell:
                    pygame.draw.rect(screen, piece.color, ((piece.x + x) * BLOCK_SIZE, (piece.y + y) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))

        draw_grid(screen)
        pygame.display.update()

    pygame.quit()

if __name__ == "__main__":
    main()
