from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

# Set your API key
openai.api_key = "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"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",   # you can change to "gpt-4"
        messages=[{"role": "user", "content": user_message}]
    )

    reply = response.choices[0].message["content"]
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)


