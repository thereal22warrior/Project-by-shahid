# Basic ML Chatbot using scikit-learn
# pip install scikit-learn

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Training data (you can add more Q&A pairs)
training_sentences = [
    "hi", "hello", "hey", 
    "how are you", "what's up", 
    "bye", "see you", "goodbye", 
    "what is your name", "who are you"
]

training_labels = [
    "greeting", "greeting", "greeting",
    "ask_wellbeing", "ask_wellbeing",
    "goodbye", "goodbye", "goodbye",
    "name", "name"
]

# Responses dictionary
responses = {
    "greeting": "Hey there! 👋",
    "ask_wellbeing": "I’m doing great, thanks for asking! How about you?",
    "goodbye": "Goodbye! Take care ✨",
    "name": "I’m your personal chatbot 🤖"
}

# Convert text to features
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(training_sentences)

# Train a Naive Bayes classifier
model = MultinomialNB()
model.fit(X, training_labels)

# Chat loop
print("Chatbot ready! Type 'quit' to stop.")
while True:
    user_input = input("You: ")
    if user_input.lower() == "quit":
        print("Chatbot: Bye 👋")
        break
    
    # Transform input
    X_test = vectorizer.transform([user_input])
    predicted_label = model.predict(X_test)[0]
    
    # Respond
    print("Chatbot:", responses.get(predicted_label, "Sorry, I didn’t get that 😅"))
