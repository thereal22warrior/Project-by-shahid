# Mini Calculator using functions and conditional statements

def calculator():
    print("---- Mini Calculator ----")
    print("Available operations: +, -, *, /, q (quit)")

    while True:
        op = input("\nEnter operation (+, -, *, /, q to quit): ")

        if op == "q":
            print("Exiting Calculator... Goodbye!")
            break

        # Only proceed if the operator is valid
        if op in ["+", "-", "*", "/"]:
            try:
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))

                if op == "+":
                    result = num1 + num2
                elif op == "-":
                    result = num1 - num2
                elif op == "*":
                    result = num1 * num2
                elif op == "/":
                    if num2 == 0:
                        print("Error: Division by zero not allowed!")
                        continue
                    result = num1 / num2

                print("Result:", result)

            except ValueError:
                print("Invalid input! Please enter numbers only.")
        else:
            print("Invalid operation! Try again.")

# Run calculator
calculator()
